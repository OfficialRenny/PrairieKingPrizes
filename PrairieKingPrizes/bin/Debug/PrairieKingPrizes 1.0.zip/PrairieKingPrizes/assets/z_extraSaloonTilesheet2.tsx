<?xml version="1.0" encoding="UTF-8"?>
<tileset name="z_extraSaloonTilesheet2" tilewidth="16" tileheight="16" tilecount="2" columns="1">
 <image source="z_extraSaloonTilesheet2.png" width="16" height="32"/>
</tileset>
